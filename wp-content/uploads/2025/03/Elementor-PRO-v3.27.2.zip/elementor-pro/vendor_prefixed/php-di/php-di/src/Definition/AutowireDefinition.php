<?php

declare (strict_types=1);
namespace ElementorProDeps\DI\Definition;

/**
 * @author Matthieu Napoli <matthieu@mnapoli.fr>
 */
class AutowireDefinition extends ObjectDefinition
{
}
